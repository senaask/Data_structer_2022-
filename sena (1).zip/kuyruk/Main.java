public class Main{//DİZİ KUYRUK KODLARI
    
    public static void main(String[] args) {
        kuyruk k =new kuyruk(10);
        k.ekle(10);
        k.ekle(15);
        k.ekle(23);
        k.ekle(12);

        int sayac=1;

        while(!k.bosmu()){//kuyrukta eleman var mı
            System.out.println(sayac+". eleman= "+k.cikart());//1. eleman 10 gibi yazdırır.
            sayac++;//eleman indis bilgisi ile yazdırmak için

        }
        while(k.bosmu()){//kuyruk boş mu
            System.out.println("Eleman kalmadı");
            break;//döngüyü kırıp çıkmak için kull. aksi halde sonsuz döngü oluşur.
        }    
    }   
}
