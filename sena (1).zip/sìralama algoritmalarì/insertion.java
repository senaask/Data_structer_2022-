public class insertion {
	
	void insertionsort(int dizi[])
	{
		int n = dizi.length;
		for (int i = 1; i < n; ++i) {
			int key = dizi[i];
			int j = i - 1;

			while (j >= 0 && dizi[j] > key) {
				dizi[j + 1] = dizi[j];
				j = j - 1;
			}
			dizi[j + 1] = key;
		}
	}

	static void print(int dizi[])
	{
		int n = dizi.length;
		for (int i = 0; i < n; ++i)
			System.out.print(dizi[i] + " ");

		System.out.println();
	}

	public static void main(String args[])
	{
		int dizi[] = { 12, 11, 13, 5, 6 };

		insertion ob = new insertion();
		ob.insertionsort(dizi);

		print(dizi);
	}
} 
