public class bubble {
    void bubblesort(int dizi[]){
        int n = dizi.length;
        for(int i= 0; i<n-1;i++){
            for(int j=0;j<n-1;i++){
                if(dizi[j]>dizi[j+1]){
                    int temp = dizi[j];
                    dizi[j]=dizi[j+1];
                    dizi[j+1]=temp;

                }
                System.out.println(i+1+"aşama 1");
            }
        }
    }
    public static void main(String[] args) {
        bubble ob = new bubble();
        int dizi[]={8,9,58,7,4,24,67,25,5,4,2,78};
        ob.bubblesort(dizi);
        System.out.println("sıralI DİZİ =");
        int n = dizi.length;
        for(int i = 0;i<n-1 ;i++){
            System.out.print(dizi[i]+",");
            
        }
        
    }
}
