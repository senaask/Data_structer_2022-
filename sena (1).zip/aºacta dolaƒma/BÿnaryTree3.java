
 
import java.util.ArrayList;
import java.util.Stack;

class Node {
    int data;
    Node left, right;
 
    Node(int item)
    {
        data = item;
        left = right;
    }
}
 
class BinaryTree {
    Node root;
 
    
    void postOrder(Node node)
    {
        Stack<Node> S = new Stack<Node>();
 
        if (node == null)
            return;
        S.push(node);
        Node prev = null;
        while (!S.isEmpty()) {
            Node current = S.peek();
 
            if (prev == null || prev.left == current
                || prev.right == current) {
                if (current.left != null)
                    S.push(current.left);
                else if (current.right != null)
                    S.push(current.right);
                else {
                    S.pop();
                    System.out.print(current.data + " ");
                }
 
             
            }
            else if (current.left == prev) {
                if (current.right != null)
                    S.push(current.right);
                else {
                    S.pop();
                    System.out.print(current.data + " ");
                }
 
            }
            else if (current.right == prev) {
                S.pop();
                System.out.print(current.data + " ");
            }
 
            prev = current;
        }
    }
 
    
    public static void main(String args[])
    {
        BinaryTree tree = new BinaryTree();
 
        tree.root = new Node(1);
        tree.root.left = new Node(2);
        tree.root.right = new Node(3);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(5);
 
        tree.postOrder(tree.root);
    }
}

