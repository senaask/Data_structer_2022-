
 import java.util.Stack;
 import java.io.*;
 // Class containing left and right child of
 // current node and key value
 class Node {
     int data;
     Node left, right;
  
     public Node(int item)
     {
         data = item;
         left = right = null;
     }
 }
  
 // Class to print the preorder traversal
 class BinaryTree {
     Node root;
     void preorder()
     {
         if (root == null) {
             return;
         }
         Stack<Node> S = new Stack<>();
  
         // Push root element in the stack
         S.add(root);
  
         // print the root element
         System.out.print(root.data + " ");
  
         // Push right subtree to the stack
         if (root.right != null) {
             S.add(root.right);
         }
         // Push left subtree to the stack
         if (root.left != null) {
             S.add(root.left);
         }
         // Iterate till Size of the Stack not equal to 1
         while (S.size() != 1) {
             // Peek element of the stack
             Node temp = S.peek();
             // pop the element from the stack
             S.pop();
  
             if (temp != null) {
                 // print the pop element
                 System.out.print(temp.data + " ");
  
                 // Push right subtree of the pop element
                 if (temp.right != null) {
                     S.add(temp.right);
                 }
                 // Push left subtree of the pop element
                 if (temp.left != null) {
                     S.add(temp.left);
                 }
             }
         }
     }
  
     public static void main(String args[])
     {
  
         // creating a binary tree and
         // entering the nodes
         BinaryTree tree = new BinaryTree();
         tree.root = new Node(1);
         tree.root.left = new Node(2);
         tree.root.right = new Node(3);
         tree.root.left.left = new Node(4);
         tree.root.left.right = new Node(5);
         tree.preorder();
     }
 }